package com.kh.chapter1;

import com.kh.chapter1.file.A_File;

public class Application {

	public static void main(String[] args) {

		new A_File().method1();
		
	}

}
